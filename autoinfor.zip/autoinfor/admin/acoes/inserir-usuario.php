<?php 
require('../includes/conexao.php');

$nome = $_POST['nome'];
$email = $_POST['email'];
$senha = md5($_POST['senha']);
$telefone = $_POST['telefone'];

$SQL = "INSERT INTO usuarios (nome, email, senha, telefone)
VALUES ('$nome', '$email', '$senha', '$telefone') ";

if(mysqli_query($conexao, $SQL)){
 echo "<script>
 location.href='../cadastrar-usuarios.php?salvo=ok';
 </script>";
}
