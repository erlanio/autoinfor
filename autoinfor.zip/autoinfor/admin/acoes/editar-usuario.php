<?php
require('../includes/conexao.php');
$nome = $_POST['nome'];
$email = $_POST['email'];
$telefone = $_POST['telefone'];
$idUsuario = $_POST['idUsuario'];

$SQL = "UPDATE 
        usuarios
        SET nome = '$nome', 
        email = '$email', 
        telefone = '$telefone'
         WHERE idUsuario = $idUsuario";

if(mysqli_query($conexao, $SQL)){
    echo "<script>
    location.href='../listar-usuarios.php?editar=ok';
    </script>";
}


