<?php
require('../includes/conexao.php');
$nomeCategoria = $_POST['categoria'];
$idCategoria = $_POST['idCategoria'];

$SQL = "UPDATE 
        categorias
        SET descCategoria = '$nomeCategoria'
         WHERE idCategoria = $idCategoria";

if(mysqli_query($conexao, $SQL)){
    echo "<script>
    location.href='../listar-categorias.php?editar=ok';
    </script>";
}
