<?php include('includes/header.php') ?>
<?php include('includes/menu-lateral.php') ?>
<?php include('includes/barra-superior.php') ?>


<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary"> Lista de Marcas</h6>
    </div>
    <div class="card-body">



        <?php
        if (isset($_GET['editar'])) { ?>

            <div class="alert alert-success">
                Alterado com sucesso!
            </div>

        <?php } ?>

        <div class="table-responsive">
            <table class="table table-bordered" id="table-usuarios" widht="100%" cellspacing="0">
                <thead>
                    <th>#ID</th>
                    <th>Marca</th>
                    <th>Ações</th>
                </thead>

                <tbody>
                    <?php
                    require('includes/conexao.php');
                    $sql = "SELECT * from marcas ORDER BY descMarca asc";
                    $resultado = mysqli_query($conexao, $sql);
                    while ($row = mysqli_fetch_assoc($resultado)) {
                    ?>
                        <tr class="centro">
                            <td><strong><?php echo $row['idMarca']  ?></strong></td>
                            <td><?php echo strtoupper($row['descMarca']);  ?></td>
                            
                            <td>
                                <a href="editar-marca.php?idMarca=<?php echo $row['idMarca'] ?>">
                                    <button class="btn btn-info">
                                        <i class="fas fa-edit"></i>
                                        Editar
                                    </button></a>
                                <a href="acoes/deletar-marca.php?idMarca=<?php echo $row['idMarca'] ?>">
                                    <button class="btn btn-danger">
                                        <i class="fas fa-trash"></i>
                                        Excluir
                                    </button>
                                </a>
                            </td>
                        </tr>
                    <?php  } ?>
                </tbody>

            </table>
        </div>
    </div>
</div>

<?php include('includes/footer.php') ?>