<?php include('includes/header.php') ?>
<?php include('includes/menu-lateral.php') ?>
<?php include('includes/barra-superior.php') ?>


<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary"> Lista de Veículos</h6>
    </div>
    <div class="card-body">



        <?php
        if (isset($_GET['editar'])) { ?>

            <div class="alert alert-success">
                Alterado com sucesso!
            </div>

        <?php } ?>

        <div class="table-responsive">
            <table class="table table-bordered" id="table-usuarios" widht="100%" cellspacing="0">
                <thead>
                    <th>#ID</th>
                    <th>Imagens</th>
                    <th>Marca</th>
                    <th>Categoria</th>
                    <th>Modelo</th>
                    <th>Ações</th>
                </thead>

                <tbody>
                    <?php
                    require('includes/conexao.php');
                    $sql = "SELECT idVeiculo, imgPrincipal, modelo, descMarca, descCategoria from veiculos JOIN marcas on marcas.idMarca = veiculos.idMarca JOIN categorias on categorias.idCategoria = veiculos.idCategoria";
                    $resultado = mysqli_query($conexao, $sql);
                    while ($row = mysqli_fetch_assoc($resultado)) {
                    ?>
                        <tr class="centro">
                            <td><strong><?php echo $row['idVeiculo']  ?></strong></td>
                            <td>

                            <img src="img/veiculos/<?php echo $row['imgPrincipal'] ?>" width="100" height="100">
                            </td>
                            <td><?php echo strtoupper($row['descMarca']);  ?></td>
                            <td><?php echo strtoupper($row['descCategoria']);  ?></td>
                            <td><?php echo strtoupper($row['modelo']);  ?></td>
                            <td>
                                <a href="editar-marca.php?idMarca=<?php echo $row['idVeiculo'] ?>">
                                    <button class="btn btn-info">
                                        <i class="fas fa-edit"></i>
                                        Editar
                                    </button></a>
                                <a href="acoes/deletar-marca.php?idMarca=<?php echo $row['idVeiculo'] ?>">
                                    <button class="btn btn-danger">
                                        <i class="fas fa-trash"></i>
                                        Excluir
                                    </button>
                                </a>
                            </td>
                        </tr>
                    <?php  } ?>
                </tbody>

            </table>
        </div>
    </div>
</div>

<?php include('includes/footer.php') ?>