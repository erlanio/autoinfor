<?php 
require('../includes/conexao.php');

$marca = $_POST['marca'];

$SQL = "INSERT INTO marcas (descMarca) VALUES ('$marca')";


if(mysqli_query($conexao, $SQL)){
    echo "<script>
    location.href='../cadastrar-marcas.php?salvo=ok';
    </script>";
   }
   