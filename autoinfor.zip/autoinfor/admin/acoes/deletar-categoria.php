<?php 
require ('../includes/conexao.php');
$idCategoria = $_GET['idCategoria'];

$sql = "delete from categorias where idCategoria = $idCategoria";

if(mysqli_query($conexao, $sql)){
 echo "
 <script>
    alert('Categoria deletada com sucesso');
    location.href='../listar-categorias.php';
 </script> 
 ";
}
