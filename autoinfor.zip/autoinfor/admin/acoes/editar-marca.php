<?php
require('../includes/conexao.php');
$nomeMarca = $_POST['marca'];
$idMarca = $_POST['idMarca'];

$SQL = "UPDATE 
        marcas
        SET descMarca = '$nomeMarca'
         WHERE idMarca = $idMarca";

if(mysqli_query($conexao, $SQL)){
    echo "<script>
    location.href='../listar-marcas.php?editar=ok';
    </script>";
}
