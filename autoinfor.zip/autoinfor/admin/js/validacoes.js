function validarUsuario() {
    var nome = document.getElementById('nome').value;
    var email = document.getElementById('email').value;
    var senha = document.getElementById('senha').value;
    var telefone = document.getElementById('telefone').value;

    if (nome == "" || email == "" || senha == "" || telefone == "") {
        document.getElementById('erro-usuario').removeAttribute('hidden');
    } else {
        document.getElementById('erro-usuario').setAttribute('hidden', true);
        document.getElementById('form-usuario').setAttribute('onsubmit', true);
    }
}

function validarEdicaoUsuario() {
    var nome = document.getElementById('nome').value;
    var email = document.getElementById('email').value;
    var telefone = document.getElementById('telefone').value;
    if (nome == "" || email == "" || telefone == "") {
        document.getElementById('erro-usuario').removeAttribute('hidden');
    } else {
        document.getElementById('erro-usuario').setAttribute('hidden', true);
        document.getElementById('form-usuario').setAttribute('onsubmit', true);
    }
}

function validarCategorias() {
    var categoria = document.getElementById('categoria').value;
    if (categoria == "") {
        document.getElementById('erro-categoria').removeAttribute('hidden');
    } else {
        document.getElementById('form-categoria').setAttribute('onsubmit', true);
        document.getElementById('erro-categoria').setAttribute('hidden', true);
    }
}

function validarMarca(){
    var marca = document.getElementById('marca').value;
    if(marca == ""){
        document.getElementById('erro-marcas').removeAttribute('hidden');
    }else{
        document.getElementById('form-marcas').setAttribute('onsubmit', false);
        document.getElementById('erro-marcas').setAttribute('hidden', true);
    }
}

function validarVeiculo(){
    var modelo = document.getElementById('modelo').value;
    var anoFaricacao = document.getElementById('ano-fabricacao').value;
    var anoModelo = document.getElementById('ano-modelo').valeu;
    var valor = document.getElementById('valor').valeu;
    var km = document.getElementById('km').valeu;
    var desc = document.getElementById('desc').valeu;

    if(
        modelo =="" ||
        anoFaricacao == "" ||
        anoModelo == "" ||
        valor == "" ||
        km == "" ||
        desc == ""
    ){
        document.getElementById('erro-veiculos').removeAttribute('hidden');
    }else{
        document.getElementById('form-veiculos').setAttribute('onsubmit', true);
        document.getElementById('erro-veiculos').setAttribute('hidden', true);
    }
}