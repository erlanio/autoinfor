<?php 
require ('../includes/conexao.php');
$idMarca = $_GET['idMarca'];

$sql = "delete from marcas where idMarca = $idMarca";

if(mysqli_query($conexao, $sql)){
 echo "
 <script>
    alert('Categoria deletada com sucesso');
    location.href='../listar-marcas.php';
 </script> 
 ";
}
