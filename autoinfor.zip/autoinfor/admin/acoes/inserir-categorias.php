<?php 
require('../includes/conexao.php');

$categoria = $_POST['categoria'];

$SQL = "INSERT INTO categorias (descCategoria) VALUES ('$categoria')";


if(mysqli_query($conexao, $SQL)){
    echo "<script>
    location.href='../cadastrar-categorias.php?salvo=ok';
    </script>";
   }
   