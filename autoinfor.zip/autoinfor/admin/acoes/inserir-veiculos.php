<?php
require('../includes/conexao.php');



//VERIFICA SE A IMAGEM FOI ANEXADA
if (isset($_FILES['imgPrincipal']['name']) && $_FILES["imgPrincipal"]["error"] == 0) {

    $arquivo_tmp = $_FILES['imgPrincipal']['tmp_name'];
    $nome = $_FILES['imgPrincipal']['name'];


    // Pega a extensao
    $extensao = strrchr($nome, '.');

    // Converte a extensao para mimusculo
    $extensao = strtolower($extensao);

    // Somente imagens, .jpg;.jpeg;.gif;.png
    // Aqui eu enfilero as extesões permitidas e separo por ';'
    // Isso server apenas para eu poder pesquisar dentro desta String
    if (strstr('.jpg;.jpeg;.gif;.png;', $extensao)) {
        // Cria um nome único para esta imagem
        // Evita que duplique as imagens no servidor.
        //NOME QUE DEVERÁ SER SALVO NO BANCO DE DADOS.
        $novoNome = md5(microtime()) . '' . $extensao;

        // Concatena a pasta com o nome
        $destino = '../img/veiculos/' . $novoNome;

        // tenta mover o arquivo para o destino
        if (@move_uploaded_file($arquivo_tmp, $destino)) {
            $categoria = $_POST['categoria'];
            $marca = $_POST['marca'];
            $modelo = $_POST['modelo'];
            $anoFabricacao = $_POST['ano-fabricacao'];
            $anoModelo = $_POST['ano-modelo'];
            $valor = $_POST['valor'];
            $km = $_POST['km'];
            $desc = $_POST['desc'];
            $dataAtual = date('Y-m-d');
            $sql = "INSERT INTO veiculos (
                idCategoria, 
                idMarca, 
                idUsuario, 
                modelo,
                anoFabricacao,
                anoModelo,
                descricao,
                valor,
                km,
                imgPrincipal,
                img1,
                img2,
                img3,
                dtCadastro,
                ativo) VALUES (
                '$categoria',
                '$marca',
                '10',
                '$modelo',
                '$anoFabricacao',
                '$anoModelo',
                '$desc',
                '$valor',
                '$km',
                '$novoNome',
                '',
                '',
                '',
                '$dataAtual',
                's'
                )
            ";
    
            if (mysqli_query($conexao, $sql)) {
                echo "<script>
            location.href='../cadastrar-veiculos.php?salvo=ok';
            </script>";
            }
        } else
            echo "Erro ao salvar o arquivo. Aparentemente você não tem permissão de escrita.<br />";
    } else
        echo "Você poderá enviar apenas arquivos \"*.jpg;*.jpeg;*.gif;*.png\"<br />";
} else {
    echo "
 <script>
    alert('Insira a imagem principal');
    location.href='../cadastrar-veiculos.php';
 </script> 
 ";
}
