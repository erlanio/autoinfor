<?php 
require ('../includes/conexao.php');
$idUsuario = $_GET['idUsuario'];

$sql = "delete from usuarios where idUsuario = $idUsuario";

if(mysqli_query($conexao, $sql)){
 echo "
 <script>
    alert('Usuário deletado com sucesso');
    location.href='../listar-usuarios.php';
 </script> 
 ";
}

?>