<?php include('includes/header.php'); ?>
<?php include('includes/menu-lateral.php'); ?>
<?php include('includes/barra-superior.php'); ?>
<?php require('includes/conexao.php'); ?>
<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Cadastrar Veículos</h1>
    </div>

    <!-- Content Row -->
    <div class="row">
        <div class="col-lg-12">
            <div class="p-5">
                <div class="alert alert-danger" id="erro-veiculos" hidden>
                    Ops! Informe todos os dados para continuar!
                </div>


                <?php
                if (isset($_GET['salvo'])) { ?>

                    <div class="alert alert-success">
                        Salvo com sucesso!
                    </div>

                <?php } ?>


                <form method="POST" action="acoes/inserir-veiculos.php" id="form-veiculos" enctype="multipart/form-data" onsubmit="return false">
                    <div class="row">
                        <div class="form-grup col-md-12">
                            <label>Categoria:</label>
                            <select name="categoria" class="form-control form-control-user">
                                <?php
                                $sql = "SELECT * FROM categorias";
                                $resultado = mysqli_query($conexao, $sql);
                                while ($row = mysqli_fetch_assoc($resultado)) {
                                ?>
                                    <option value="<?php echo $row['idCategoria'] ?>">
                                        <?php echo strtoupper($row['descCategoria']) ?>
                                    </option>

                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-grup col-md-12">
                            <label>Marca:</label>
                            <select name="marca" class="form-control form-control-user">
                                <?php
                                $sql = "SELECT * FROM marcas";
                                $resultado = mysqli_query($conexao, $sql);
                                while ($row = mysqli_fetch_assoc($resultado)) {
                                ?>
                                    <option value="<?php echo $row['idMarca'] ?>">
                                        <?php echo strtoupper($row['descMarca']) ?>
                                    </option>

                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label>Modelo:</label>
                            <input type="text" class="form-control form-control-user" id="modelo" name="modelo">

                        </div>

                        <div class="form-group col-md-3">
                            <label>Ano de Fabricação:</label>
                            <input type="text" class="form-control form-control-user" id="ano-fabricacao" name="ano-fabricacao">
                        </div>

                        <div class="form-group col-md-3">
                            <label>Ano Modelo:</label>
                            <input type="text" class="form-control form-control-user" id="ano-modelo" name="ano-modelo">
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-3">
                            <label>Valor:</label>
                            <input type="text" class="form-control form-control-user" id="valor" name="valor">
                        </div>

                        <div class="form-group col-md-3">
                            <label>KM:</label>
                            <input type="text" class="form-control form-control-user" id="km" name="km">
                        </div>

                        <div class="form-group col-md-6">
                            <label>Descrição:</label>
                            <input type="text" class="form-control form-control-user" id="desc" name="desc">
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-3">
                            <label>Imagem principal:</label>
                            <input type="file" class="form-control form-control-user" id="imgPrincipal" name="imgPrincipal">
                        </div>

                        <div class="form-group col-md-3">
                            <label>Imagem 1:</label>
                            <input type="file" class="form-control form-control-user" id="img1" name="img1">
                        </div>

                        <div class="form-group col-md-3">
                            <label>Imagem 2:</label>
                            <input type="file" class="form-control form-control-user" id="img2" name="img2">
                        </div>

                        <div class="form-group col-md-3">
                            <label>Imagem 3:</label>
                            <input type="file" class="form-control form-control-user" id="img3" name="img3">
                        </div>
                    </div>
                    <button class="btn btn-success offset-3 col-md-6 col-xs-12" onclick="validarVeiculo()">Salvar Veículo</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>