<?php include('includes/header.php') ?>
<?php include('includes/menu-lateral.php') ?>
<?php include('includes/barra-superior.php') ?>


<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary" Lista de Usuários></h6>
    </div>
    <div class="card-body">



        <?php
        if (isset($_GET['editar'])) { ?>

            <div class="alert alert-success">
                Alterado com sucesso!
            </div>

        <?php } ?>

        <div class="table-responsive">
            <table class="table table-bordered" id="table-usuarios" widht="100%" cellspacing="0">
                <thead>
                    <th>#ID</th>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>Telefone</th>
                    <th>Ações</th>
                </thead>

                <tbody>
                    <?php
                    require('includes/conexao.php');
                    $sql = "select idUsuario, nome, email, telefone from usuarios order by idUsuario DESC";
                    $resultado = mysqli_query($conexao, $sql);
                    while ($row = mysqli_fetch_assoc($resultado)) {
                    ?>
                        <tr class="centro">
                            <td><strong><?php echo $row['idUsuario']  ?></strong></td>
                            <td><?php echo strtoupper($row['nome']);  ?></td>
                            <td><?php echo strtoupper($row['email']) ?></td>
                            <td><?php echo $row['telefone']  ?></td>
                            <td>
                                <a href="editar-usuario.php?id=<?php echo $row['idUsuario'] ?>">
                                    <button class="btn btn-info">
                                        <i class="fas fa-edit"></i>
                                        Editar
                                    </button></a>
                                <a href="acoes/deletar-usuario.php?idUsuario=<?php echo $row['idUsuario'] ?>">
                                    <button class="btn btn-danger">
                                        <i class="fas fa-trash"></i>
                                        Excluir
                                    </button>
                                </a>
                            </td>
                        </tr>
                    <?php  } ?>
                </tbody>

            </table>
        </div>
    </div>
</div>

<?php include('includes/footer.php') ?>